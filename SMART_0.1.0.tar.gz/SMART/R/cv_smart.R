#library(Rcpp);library(RcppEigen);library(MASS);library(glmnet);library(prclust)
#sourceCpp("try1.cpp")
utils::globalVariables("rand")

cv_smart <- function(X, Y, 
                     lambda1_vals = NULL, lambda2_vals = NULL, lambda3_vals = NULL, tau_vals = NULL,
                     rho = NULL, iter_dc = NULL, iter_admm = NULL, tol_p = NULL, tol_d = NULL) {
  K <- length(X)
  p <- ncol(X[[1]])
  sample_sizes <- sapply(Y, length)
  interval1 <- sqrt(log(p)/(0.5*sum(sample_sizes)))
  interval2 <- 10^(seq(-1,1,length.out=5))*interval1#Make the numbers approaching 0 denser.
  interval3 <- 1:5
  if (is.null(lambda1_vals)) lambda1_vals <- interval2
  if (is.null(lambda2_vals)) lambda2_vals <- interval2
  if (is.null(lambda3_vals)) lambda3_vals <- interval2
  if (is.null(tau_vals)) tau_vals <- interval3
  if (is.null(rho)) rho <- 0.4
  if (is.null(iter_dc)) iter_dc <- 3000
  if (is.null(iter_admm)) iter_admm <- 3000
  if (is.null(tol_p)) tol_p <- 1e-3
  if (is.null(tol_d)) tol_d <- 1e-3
  beta0=NULL
  for(k in 1:length(X)){
    lasso_k <- cv.glmnet(X[[k]], Y[[k]], alpha = 0.5,intercept = FALSE, grouped = FALSE)   # alpha=1表示Lasso回归
    i_beta_k <- matrix(coef(lasso_k))[-1]
    beta0=rbind(beta0,i_beta_k)
  }
  # Initialize the data frame used to store results
  results <- data.frame(
    rand = numeric(),
    lambda1 = numeric(),
    lambda2 = numeric(),
    lambda3 = numeric(),
    tau = numeric(),
    stringsAsFactors = FALSE
  )

  # Create a list to store cached smart results
  slgtlp_cache <- list()

  for (lambda1 in lambda1_vals) {
    for (lambda2 in lambda2_vals) {
      for (lambda3 in lambda3_vals) {
        for (tau in tau_vals) {
          rand_total <- 0
          valid_param <- TRUE

          # Generate a unique key for the current parameter combination
          param_key <- paste(lambda1, lambda2, lambda3, tau, sep = "_")

          # Check if the result is already cached
          if (!is.null(slgtlp_cache[[param_key]])) {
            result <- slgtlp_cache[[param_key]]
          } else {
            # Run the smart algorithm on the dataset and cache the result
            result <- smart(X, Y, beta0, lambda1, lambda2, lambda3, tau, rho, iter_dc, iter_admm, tol_p, tol_d)
            selected_result <- list(
              beta = result$beta,
              delta = result$delta,
              group = result$group,
              lambda = result$lambda
            )
            slgtlp_cache[[param_key]] <- selected_result
          }

          group1 <- result$group
          for (k in 1:K) {
            # Calculate the number of non-zero elements in the k-th task.
            num_nonzero_in_layer <- sum(result$beta[k, ] != 0)

            # Check the grouping situation of the k-th task.
            if (length(unique(group1[k, ])) > num_nonzero_in_layer || length(unique(group1[k, ])) == 1) {
              # If any row meets the condition, invalidate the parameter and remove it from the cache.
              valid_param <- FALSE
              slgtlp_cache[[param_key]] <- NULL
              break  # Exit the loop immediately after finding a row that meets the condition.
            }
          }

          if (valid_param) {
            for (rep in 1:5) {
              # Randomly delete 10% of the variables
              p <- ncol(X[[1]])
              delete_indices <- sample(1:p, size =  max(floor(0.1 * p), 1))

              X_new <- lapply(X, function(mat) mat[, -delete_indices, drop = FALSE])
              beta_del <- result$beta[, delete_indices, drop = FALSE]
              Y_tilde <- lapply(1:K, function(k) {
                Y[[k]] - X[[k]][, delete_indices, drop = FALSE] %*% beta_del[k, ]
              })

              beta0new=NULL
              for(k in 1:length(X)){
                lasso_k <- cv.glmnet(X_new[[k]], Y_tilde[[k]], alpha = 0.5,intercept = FALSE, grouped = FALSE)   # alpha=1表示Lasso回归
                i_beta_k <- matrix(coef(lasso_k))[-1]
                beta0new=rbind(beta0new,i_beta_k)
              }

              result_new <- smart(X_new, Y_tilde, beta0new, lambda1, lambda2, lambda3, tau, rho, iter_dc, iter_admm, tol_p, tol_d)
              group2 <- result_new$group
              group1_adj <- t(apply(group1, 1, function(row) row[-delete_indices]))
              rand_values <- numeric(nrow(group2))
              for (i in 1:nrow(group2)) {
                rand_values[i] = clusterStat(group1_adj[i,],group2[i,])$Rand
              }
              rand_index <- mean(rand_values)
              rand_total <- rand_total + rand_index


            }

            rand_avg <- rand_total / 5
            results <- rbind(results, data.frame(rand = rand_avg, lambda1 = lambda1, lambda2 = lambda2, lambda3 = lambda3, tau = tau))
          }
        }
      }
    }
  }

  top_results <- subset(results, rand >= 0.95)
  n <- sum(lengths(Y))
  # calculate  BIC
  bic_results <- data.frame(bic = numeric(), lambda1 = numeric(), lambda2 = numeric(), lambda3 = numeric(), tau = numeric())

  for (i in 1:nrow(top_results)) {
    lambda1 <- top_results$lambda1[i]
    lambda2 <- top_results$lambda2[i]
    lambda3 <- top_results$lambda3[i]
    tau <- top_results$tau[i]

    # Retrieve the cached result
    param_key <- paste(lambda1, lambda2, lambda3, tau, sep = "_")
    result <- slgtlp_cache[[param_key]]

    beta_estimates <- result$beta
    nonzero <- sum(beta_estimates != 0)  # The number of non-zero.

    total_rss <- 0
    for (k in 1:K) {
      Y_pred <- X[[k]] %*% beta_estimates[k,]
      rss <- sum((Y[[k]] - Y_pred)^2)
      total_rss <- total_rss + rss
    }

    log_likelihood <- -n/2 * log(total_rss / n)
    # calculate BIC
    bic <- -2 * log_likelihood + log(n) * nonzero

    bic_results <- rbind(bic_results, data.frame(bic = bic, lambda1 = lambda1, lambda2 = lambda2, lambda3 = lambda3, tau = tau))
  }

  # Choose the parameter combination with the smallest BIC.
  best_params <- bic_results[which.min(bic_results$bic),]
  res <- smart(X, Y, beta0, lambda1=best_params[,2], lambda2=best_params[,3], lambda3=best_params[,4], tau=best_params[,5], rho, iter_dc, iter_admm, tol_p, tol_d)
  return(res)
}

