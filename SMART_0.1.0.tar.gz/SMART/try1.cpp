#include <RcppEigen.h>
#include <cmath>
#include <vector>
#include <algorithm>

using namespace Rcpp;
using namespace Eigen;

// [[Rcpp::depends(RcppEigen)]]

// TLP function in C++
double TLP(double x, double tau) {
  return std::abs(x) > tau ? tau : std::abs(x);
}

// soft_thresholding function in C++
Eigen::VectorXd soft_thresholding(Eigen::VectorXd z, double lambda) {
  Eigen::VectorXd s = z.array().sign() * (z.array().abs() - lambda).max(0);
  return s;
}

// compute_Z function in C++
// [[Rcpp::export]]
std::vector<Eigen::MatrixXd> compute_Z(List X_list) {
  int n = 0;
  for (int i = 0; i < X_list.size(); ++i) {
    n += as<MatrixXd>(X_list[i]).rows();
  }
  int p = as<MatrixXd>(X_list[0]).cols();
  int K = X_list.size();
  
  std::vector<Eigen::MatrixXd> Z(p, Eigen::MatrixXd::Zero(n, K));
  
  int row_start = 0;
  for (int j = 0; j < p; ++j) {
    row_start = 0;
    for (int k = 0; k < K; ++k) {
      Eigen::MatrixXd X_k = as<MatrixXd>(X_list[k]);
      int n_k = X_k.rows();
      Z[j].block(row_start, k, n_k, 1) = X_k.col(j);
      row_start += n_k;
    }
  }
  return Z;
}

// Function to merge Y_list into a single VectorXd
Eigen::VectorXd merge_Y_list(List Y_list) {
  int total_rows = 0;
  for (int i = 0; i < Y_list.size(); ++i) {
    total_rows += as<VectorXd>(Y_list[i]).size();
  }

  Eigen::VectorXd Y_vector(total_rows);
  int current_row = 0;

  for (int i = 0; i < Y_list.size(); ++i) {
    Eigen::VectorXd Y_i = as<VectorXd>(Y_list[i]);
    Y_vector.segment(current_row, Y_i.size()) = Y_i;
    current_row += Y_i.size();
  }

  return Y_vector;
}

// loss function in C++
// [[Rcpp::export]]
double loss(List Y_list, const std::vector<Eigen::MatrixXd> &Z, Eigen::MatrixXd beta, double tau, double lambda1, double lambda2, double lambda3) {
  Eigen::VectorXd Y_vec = merge_Y_list(Y_list);
  
  Eigen::VectorXd Zbeta = Eigen::VectorXd::Zero(Y_vec.size());
  for (int j = 0; j < beta.cols(); ++j) {
    Zbeta += Z[j] * beta.col(j);
  }
  
  double term1 = 0.5 * (Y_vec - Zbeta).squaredNorm();
  double term2 = lambda1 * beta.array().abs().sum();
  double term3 = lambda2 * beta.colwise().norm().sum();
  double term4 = 0;
  
  for (int j = 0; j < beta.cols() - 1; ++j) {
    for (int jp = j + 1; jp < beta.cols(); ++jp) {
      term4 += lambda3 * TLP((beta.col(j) - beta.col(jp)).norm(), tau);
    }
  }
  return (term1 + term2 + term3 + term4);
}

// compute_yz_star function in C++
// [[Rcpp::export]]
List compute_yz_star(List Y_list, const std::vector<Eigen::MatrixXd> &Z, Eigen::MatrixXd beta, Eigen::MatrixXd delta, Eigen::MatrixXd v, int k, double rho) {
  Eigen::VectorXd Y_vec = merge_Y_list(Y_list);

  int n = Y_vec.size();
  int K = beta.rows();
  int p = beta.cols();

  // Compute r_(-k)
  Eigen::VectorXd r_minus_k = Y_vec;
  for (int j = 0; j < p; ++j) {
    if (j != k) {
      r_minus_k -= Z[j] * beta.col(j);
    }
  }

  Eigen::MatrixXd Z_k = Z[k];

  // Initialize cZ_1, cY_1, cZ_2, and cY_2 matrices
  Eigen::MatrixXd cZ_1 = Eigen::MatrixXd::Zero((k) * K, K);
  Eigen::VectorXd cY_1 = Eigen::VectorXd::Zero((k) * K);
  Eigen::MatrixXd cZ_2 = Eigen::MatrixXd::Zero((p - k - 1) * K, K);
  Eigen::VectorXd cY_2 = Eigen::VectorXd::Zero((p - k - 1) * K);

  if (k > 0) {
    for (int i = 0; i < k; ++i) {
      cZ_1.block(i * K, 0, K, K) = -Eigen::MatrixXd::Identity(K, K);
      cY_1.segment(i * K, K) = delta.block(i * K, k, K, 1) - beta.col(i) + v.block(i * K, k, K, 1);
    }
  }

  if (k < p - 1) {
    for (int i = 0; i < p - k - 1; ++i) {
      cZ_2.block(i * K, 0, K, K) = Eigen::MatrixXd::Identity(K, K);
      cY_2.segment(i * K, K) = delta.block((k * K), k + 1 + i, K, 1) + beta.col(k + 1 + i) + v.block((k * K), k + 1 + i, K, 1);
    }
  }

  int total_rows = Z_k.rows() + cZ_1.rows() + cZ_2.rows();
  Eigen::MatrixXd bz_star_k = Eigen::MatrixXd::Zero(total_rows, K);
  bz_star_k.topRows(Z_k.rows()) = Z_k / std::sqrt(rho);
  bz_star_k.middleRows(Z_k.rows(), cZ_1.rows()) = cZ_1;
  bz_star_k.bottomRows(cZ_2.rows()) = cZ_2;
  bz_star_k *= std::sqrt(rho);

  Eigen::VectorXd by_star_k(total_rows);
  by_star_k.head(Z_k.rows()) = r_minus_k / std::sqrt(rho);
  by_star_k.segment(Z_k.rows(), cY_1.rows()) = cY_1;
  by_star_k.tail(cY_2.rows()) = cY_2;
  by_star_k *= std::sqrt(rho);

  return List::create(Named("by_star_k") = by_star_k, Named("bz_star_k") = bz_star_k);
}


// generate_groups function in C++
// [[Rcpp::export]]
std::vector<int> generate_groups(List Y_list) {
  std::vector<int> groups;
  for (int i = 0; i < Y_list.size(); ++i) {
    Eigen::VectorXd Y = as<VectorXd>(Y_list[i]);
    for (int j = 0; j < Y.size(); ++j) {
      groups.push_back(i + 1);
    }
  }
  return groups;
}

// update_beta_k function in C++
// [[Rcpp::export]]
Eigen::VectorXd update_beta_k(Eigen::VectorXd beta_k_l, Eigen::VectorXd by_star_k, Eigen::MatrixXd bz_star_k, double lambda1, double lambda2) {
  Eigen::MatrixXd XTX = bz_star_k.transpose() * bz_star_k;
  double max_eigen = XTX.eigenvalues().real().maxCoeff();
  double t = 1.0 / max_eigen;


  //Eigen::VectorXd grad_l = -bz_star_k.transpose() * (by_star_k - bz_star_k * beta_k_l);
  Eigen::VectorXd grad_l = -bz_star_k.transpose() * by_star_k  + bz_star_k.transpose() * bz_star_k * beta_k_l;
  Eigen::VectorXd soft_thresh = soft_thresholding(beta_k_l - t * grad_l, t * lambda1);
  double norm_soft_thresh = soft_thresh.norm();
  
  Eigen::VectorXd beta_l1_k;
  if (norm_soft_thresh <= t * lambda2) {
    beta_l1_k = Eigen::VectorXd::Zero(beta_k_l.size());
  } else {
    double scaling_factor = std::max(1 - t * lambda2 / norm_soft_thresh, 0.0);
    beta_l1_k = scaling_factor * soft_thresh;
  }
  return beta_l1_k;
}

// block_soft_thresholding function in C++
// [[Rcpp::export]]
Eigen::VectorXd block_soft_thresholding(Eigen::VectorXd delta, double gamma) {
  double norm_delta = delta.norm();
  if (norm_delta > gamma) {
    return (norm_delta - gamma) / norm_delta * delta;
  } else {
    return Eigen::VectorXd::Zero(delta.size());
  }
}

// update_delta_kkp function in C++
// [[Rcpp::export]]
Eigen::VectorXd update_delta_kkp(Eigen::VectorXd beta_l1_k, Eigen::VectorXd beta_l1_kp, Eigen::VectorXd v_kk_prime, Eigen::VectorXd delta_m, double tau, double lambda3, double rho) {
  double norm_delta_m = delta_m.norm();
  Eigen::VectorXd delta_l1_kk_prime;
  
  if (norm_delta_m >= tau) {
    delta_l1_kk_prime = beta_l1_k - beta_l1_kp - v_kk_prime;
  } else {
    delta_l1_kk_prime = block_soft_thresholding(beta_l1_k - beta_l1_kp - v_kk_prime, lambda3 / rho);
  }
  
  return delta_l1_kk_prime;
}

// update_v function in C++
// [[Rcpp::export]]
Eigen::VectorXd update_v(Eigen::VectorXd v_l_kk_prime, Eigen::VectorXd delta_l1_kk_prime, Eigen::VectorXd beta_l1_k, Eigen::VectorXd beta_l1_k_prime) {
  Eigen::VectorXd v_l1_kk_prime = v_l_kk_prime + delta_l1_kk_prime - (beta_l1_k - beta_l1_k_prime);
  return v_l1_kk_prime;
}

// iter_update_beta_k function in C++
// [[Rcpp::export]]
Eigen::VectorXd iter_update_beta_k(Eigen::VectorXd beta_k_l, Eigen::VectorXd by_star_k, Eigen::MatrixXd bz_star_k, double lambda1, double lambda2) {
  double change = 100;
  int n = 1;
  while (change > 0.1 && n <= 1000) {
    Eigen::VectorXd beta_l1_k = update_beta_k(beta_k_l, by_star_k, bz_star_k, lambda1, lambda2);
    change = (beta_l1_k - beta_k_l).norm();
    beta_k_l = beta_l1_k;
    ++n;
  }
  return beta_k_l;
}

// admm_iteration function in C++
// [[Rcpp::export]]
List admm_iteration(List Y_list, const std::vector<Eigen::MatrixXd> Z, Eigen::MatrixXd beta, Eigen::MatrixXd delta, Eigen::MatrixXd delta_m, Eigen::MatrixXd v, double lambda1, double lambda2, double lambda3, double tau, double rho, int iter_admm, double tol_p, double tol_d) {
  int K = beta.rows();
  int p = beta.cols();
  
  int n_tem = 0;
  List loss_admm;
  while (n_tem <= iter_admm) {
    Eigen::MatrixXd beta_previous = beta;
    Eigen::MatrixXd v_previous = v;
    Eigen::MatrixXd delta_previous = delta;
    
    for (int k = 0; k < p; ++k) {
      List byz_star_k = compute_yz_star(Y_list, Z, beta, delta, v, k, rho);
      Eigen::VectorXd by_star_k = byz_star_k["by_star_k"];
      Eigen::MatrixXd bz_star_k = byz_star_k["bz_star_k"];
      beta.col(k) = iter_update_beta_k(beta_previous.col(k), by_star_k, bz_star_k, lambda1, lambda2);
    }
    
    for (int k = 0; k < p - 1; ++k) {
      for (int kp = k + 1; kp < p; ++kp) {
        int delta_index_start = k * K;
        int delta_index_end = delta_index_start + K;
        delta.block(delta_index_start, kp, K, 1) = update_delta_kkp(beta.col(k), beta.col(kp), v.block(delta_index_start, kp, K, 1), delta_m.block(delta_index_start, kp, K, 1), tau, lambda3, rho);
      }
    }
    
    for (int k = 0; k < p - 1; ++k) {
      for (int kp = k + 1; kp < p; ++kp) {
        int v_index_start = k * K;
        int v_index_end = v_index_start + K;
        v.block(v_index_start, kp, K, 1) = update_v(v.block(v_index_start, kp, K, 1), delta.block(v_index_start, kp, K, 1), beta.col(k), beta.col(kp));
      }
    }
    
    n_tem += 1;
    loss_admm.push_back(loss(Y_list, Z, beta, tau, lambda1, lambda2, lambda3));
    
    double primal_res = 0;
    double dual_res = 0;
    for (int k = 0; k < p - 1; ++k) {
      for (int kp = k + 1; kp < p; ++kp) {
        int delta_index_start = k * K;
        int delta_index_end = delta_index_start + K;
        Eigen::VectorXd r_kkp = beta.col(k) - beta.col(kp) - delta.block(delta_index_start, kp, K, 1);
        Eigen::VectorXd s_kkp = rho * (delta.block(delta_index_start, kp, K, 1) - delta_previous.block(delta_index_start, kp, K, 1));
        primal_res += r_kkp.squaredNorm();
        dual_res += s_kkp.squaredNorm();
      }
    }
    primal_res = std::sqrt(primal_res);
    dual_res = std::sqrt(dual_res);
    
    if (primal_res <= tol_p && dual_res <= tol_d) {
      break;
    }
  }
  
  return List::create(Named("beta") = beta, Named("delta") = delta, Named("v") = v, Named("loss_admm") = loss_admm);
}

// compute_delta function in C++
// [[Rcpp::export]]
Eigen::MatrixXd compute_delta(Eigen::MatrixXd beta) {
  int K = beta.rows();
  int p = beta.cols();
  Eigen::MatrixXd delta = Eigen::MatrixXd::Zero(K * p, p);
  for (int j = 0; j < p - 1; ++j) {
    for (int jp = j + 1; jp < p; ++jp) {
      int delta_index_start = j * K;
      int delta_index_end = delta_index_start + K;
      delta.block(delta_index_start, jp, K, 1) = beta.col(j) - beta.col(jp);
    }
  }
  return delta;
}

// [[Rcpp::export]]
IntegerMatrix find_groups(NumericMatrix delta) {
  int p = delta.ncol();
  int K = delta.nrow() / p;

  // 初始化分组变量group，现在是K*p的矩阵
  IntegerMatrix group(K, p);

  // 辅助函数：找到某个节点的根
  std::function<int(int, int)> find_root = [&group, &find_root](int layer, int node) -> int {
    if (group(layer, node) != node) {
      group(layer, node) = find_root(layer, group(layer, node));
    }
    return group(layer, node);
  };

  // 初始化group变量，将每个节点的初始根节点设置为自己
  for (int j = 0; j < p; ++j) {
    for (int i = 0; i < K; ++i) {
      group(i, j) = j;
    }
  }

  // 遍历所有的i, j组合，判断每层的deltaij是否为0
  for (int i = 0; i < p - 1; ++i) {
    for (int j = i + 1; j < p; ++j) {
      for (int k = 0; k < K; ++k) {
        if (delta(k + i * K, j) == 0) {
          // 找到i和j在当前层k的根
          int root_i = find_root(k, i);
          int root_j = find_root(k, j);

          // 如果i和j的根不相同，将它们合并
          if (root_i != root_j) {
            group(k, root_j) = root_i;
          }
        }
      }
    }
  }

  // 为每个节点在每个层上找到最终的根
  for (int j = 0; j < p; ++j) {
    for (int i = 0; i < K; ++i) {
      group(i, j) = find_root(i, j);
    }
  }

  // 将根节点重新编号为1, 2, 3, ...
  std::unordered_map<int, int> root_map;
  int new_label = 1;
  for (int j = 0; j < p; ++j) {
    for (int i = 0; i < K; ++i) {
      int root = group(i, j);
      if (root_map.find(root) == root_map.end()) {
        root_map[root] = new_label++;
      }
      group(i, j) = root_map[root];
    }
  }

  return group;
}







// SMART function in C++
// [[Rcpp::export]]
List smart(List X_list,List Y_list, Eigen::MatrixXd beta0, double lambda1, double lambda2, double lambda3, double tau, double rho, int iter_dc, int iter_admm, double tol_p, double tol_d) {
  std::vector<Eigen::MatrixXd> Z = compute_Z(X_list);
  int K = X_list.size();
  int p = as<MatrixXd>(X_list[0]).cols();
  int n = 0;
  for (int i = 0; i < X_list.size(); ++i) {
    n += as<MatrixXd>(X_list[i]).rows();
  }
  
  Eigen::MatrixXd v0 = Eigen::MatrixXd::Zero(K * p, p);
    
  Eigen::MatrixXd delta0 = compute_delta(beta0);
  List loss_dcadmm;
  List loss_dc;
  int m = 0;
  
  while (m <= iter_dc) {
    ++m;
    List admm_result = admm_iteration(Y_list, Z, beta0, delta0, delta0, v0, lambda1, lambda2, lambda3, tau, rho, iter_admm, tol_p, tol_d);
    beta0 = as<MatrixXd>(admm_result["beta"]);
    delta0 = as<MatrixXd>(admm_result["delta"]);
    loss_dcadmm.push_back(admm_result["loss_admm"]);
    loss_dc.push_back(loss(Y_list, Z, beta0, tau, lambda1, lambda2, lambda3));
    
    int loss_size = loss_dc.size();
    if (loss_size >= 2) {
      double last_loss = as<double>(loss_dc[loss_size - 1]);
      double second_last_loss = as<double>(loss_dc[loss_size - 2]);
      if (last_loss == second_last_loss) {
        break;
      }
    }
  }
  // 转换 delta0 为 NumericMatrix 类型
  NumericMatrix delta0_numeric(delta0.rows(), delta0.cols());
  for (int i = 0; i < delta0.rows(); ++i) {
    for (int j = 0; j < delta0.cols(); ++j) {
      delta0_numeric(i, j) = delta0(i, j);
    }
  }
  
  IntegerVector group = find_groups(delta0_numeric);
  // 创建 lambda 向量
  NumericVector lambda = NumericVector::create(lambda1, lambda2, lambda3, tau);
  return List::create(Named("beta") = beta0, Named("loss_dc") = loss_dc, Named("loss_dcadmm") = loss_dcadmm, Named("iter_num") = m, Named("delta") = delta0, Named("group") = group, Named("lambda") = lambda);
}